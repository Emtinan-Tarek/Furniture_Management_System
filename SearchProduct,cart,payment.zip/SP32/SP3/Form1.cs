﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace SP3
{
    public partial class Form1 : Form
    {
        string ordb = "Data Source=ORCL;User Id=scott;Password=tiger;";
        OracleConnection conn;
        public Form1()
        {
            InitializeComponent();
        }
        public class Order
        {
            
            public string name;
            public int quantity;

            public Order(string name, int quantity)
            {
                this.name = name;
                this.quantity = quantity;
            }
        }
        public static List<Order> OrderList = new List<Order>();
        public static List<string> prodnames = new List<string>();
        private void Form1_Load(object sender, EventArgs e)
        {   
            conn = new OracleConnection(ordb);
            conn.Open();

            
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = conn;

            cmd.CommandText = "select product_category from Product";
            cmd.CommandType = System.Data.CommandType.Text;

            OracleDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
           {
                 string val = dr["Product_Category"].ToString();

                  if (!comboBox1.Items.Contains(val)) {
                        comboBox1.Items.Add(val);
                  }


            }
              dr.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            OracleCommand cmd2 = new OracleCommand();
            cmd2.Connection = conn;
            cmd2.CommandText = "FillProductsComboBox";
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.Parameters.Add("Categ", comboBox1.SelectedItem.ToString());
            cmd2.Parameters.Add("Products", OracleDbType.RefCursor, ParameterDirection.Output);
            
            OracleDataReader dr = cmd2.ExecuteReader();
            while (dr.Read())
            {
               comboBox2.Items.Add(dr[0]);
            }
            dr.Close();

                //cmd2.CommandText = "select product_name from product where product_category=:categ";
                //cmd2.CommandType = System.Data.CommandType.Text;
                //cmd2.Parameters.Add("categ", comboBox1.SelectedItem.ToString());

                //OracleDataReader dr = cmd2.ExecuteReader();
                //while (dr.Read())
                //{
                //    comboBox2.Items.Add(dr["Product_name"]);

                //}
                //dr.Close();

        }

        public static int total_price = 0;
        public static int indexes = 0;
       
        private void button1_Click(object sender, EventArgs e)
        {
            OrderList.Add(new Order(comboBox2.SelectedItem.ToString(), Int32.Parse(textBox1.Text)));
            prodnames.Add(comboBox2.SelectedItem.ToString());

            MessageBox.Show("Items Added to Cart");
            OracleCommand cmd3 = new OracleCommand();
            cmd3.Connection = conn;

            cmd3.CommandText = "GetProductPrice";
            cmd3.CommandType = CommandType.StoredProcedure;
            cmd3.Parameters.Add("input_name", comboBox2.SelectedItem.ToString());
            cmd3.Parameters.Add("output_price", OracleDbType.Int32).Direction = ParameterDirection.Output;

            int rdd = cmd3.ExecuteNonQuery();

            
            String prices = cmd3.Parameters["output_price"].Value.ToString();
            int test = Int32.Parse(prices);
            int times = OrderList.ElementAt(indexes).quantity;
            total_price += test * times; 
            
            indexes++;



        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            OracleCommand cmd3 = new OracleCommand();
            cmd3.Connection = conn;
            cmd3.CommandText = "select photos from product where product_name=:name";
            cmd3.CommandType = System.Data.CommandType.Text;
            cmd3.Parameters.Add("name", comboBox2.SelectedItem.ToString());

            OracleDataReader dr = cmd3.ExecuteReader();
            while (dr.Read())
            {
               
                pictureBox1.Image = Image.FromFile(dr["photos"].ToString());
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            }
            dr.Close();


        }
        public int newid = 0;
        public int prodid = 0;
        private void button2_Click(object sender, EventArgs e)
        {  

            OracleCommand cmd3 = new OracleCommand();
            cmd3.Connection = conn;
            cmd3.CommandText = "select greatest(order_id) from orders";
            cmd3.CommandType = System.Data.CommandType.Text;

            OracleDataReader d = cmd3.ExecuteReader();
            while (d.Read())
            {
                String ids = d[0].ToString();
                int idt = Int32.Parse(ids);
                newid = idt;

            }d.Close();

            
            OracleCommand cmd4 = new OracleCommand();
            cmd4.Connection = conn;
            cmd4.CommandText = "insert into Orders values(:id,:price,:datetod)";
            cmd4.Parameters.Add("id", ++newid);
            cmd4.Parameters.Add("price", Form1.total_price);
            cmd4.Parameters.Add("datetod", OracleDbType.Date).Value = DateTime.Today; 

            int r = cmd4.ExecuteNonQuery();
            
            if (r != -1)
            {
                MessageBox.Show("done");
            }
            
            for (int i = 0; i < prodnames.Count(); i++)
            {
               OracleCommand cmd6 = new OracleCommand();
               cmd6.Connection = conn;
               cmd6.CommandText = "insert into Order_products values(:name,:id)";
               cmd6.Parameters.Add("name", prodnames[i]);
               cmd6.Parameters.Add("id", newid);

               int reads = cmd6.ExecuteNonQuery();
                
                OracleCommand cmd8 = new OracleCommand();
                cmd8.Connection = conn;
                cmd8.CommandText = "select product_id from product where product_name=:name";
                cmd8.CommandType = System.Data.CommandType.Text;
                cmd8.Parameters.Add("name", prodnames[i]);

                OracleDataReader readata = cmd8.ExecuteReader();
                while (readata.Read())
                {
                   String prodids = readata[0].ToString();
                   int prodidt = Int32.Parse(prodids);
                   prodid = prodidt;

                }
                readata.Close();

                OracleCommand cmd9 = new OracleCommand();
                cmd9.Connection = conn;
                cmd9.CommandText = "insert into contains values(:oid,:pid)";
                cmd9.Parameters.Add("oid", newid);
                cmd9.Parameters.Add("pid", prodid);

                int readsdata = cmd9.ExecuteNonQuery();
            }

            //OracleCommand cmd7 = new OracleCommand();
            //cmd7.Connection = conn;
            //cmd7.CommandText = "insert into Make values(:user,:id)";
            //cmd7.Parameters.Add("name",Formx.USERNAMEvariable.toString() ); //create variable to store user name when logged in or registered
            //cmd7.Parameters.Add("id", newid);
            //int datar = cmd7.ExecuteNonQuery();

            
            

            this.Hide();
            Cart obj = new Cart();//change 'Form3' depending on the name u have 
            obj.Show();

            
        }
    }
    
}
