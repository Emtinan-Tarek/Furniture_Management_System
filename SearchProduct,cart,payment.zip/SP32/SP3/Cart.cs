﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Oracle.DataAccess.Client;

namespace SP3
{
    public partial class Cart : Form
    {
        string ordb = "Data Source=ORCL;User Id=scott;Password=tiger;";
        OracleConnection conn;
        public Cart()
        {
            InitializeComponent();
        }

        private void checkout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Payment obj = new Payment();//change 'Form3' depending on the name u have 
            obj.Show();
        }
        private void Cart_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < Form1.OrderList.Count(); i++)
            {
                string item2 = Form1.OrderList.ElementAt(i).name.ToString();
                comboBox1.Items.Add(item2);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            int index = comboBox1.SelectedIndex;
            string labeltext = Form1.OrderList.ElementAt(index).quantity.ToString();
            label1.Text = labeltext.ToString();

            conn = new OracleConnection(ordb);
            conn.Open();
            OracleCommand cmd2 = new OracleCommand();
            cmd2.Connection = conn;
            cmd2.CommandText = "select price from product where product_name=:name";
            cmd2.CommandType = System.Data.CommandType.Text;
            cmd2.Parameters.Add("name", comboBox1.SelectedItem.ToString());

            OracleDataReader dr = cmd2.ExecuteReader();
            while (dr.Read())
            {
                label5.Text = dr["price"].ToString();
               
            }
     dr.Close();

          
           label7.Text= Form1.total_price.ToString();
        }

        private void checkout_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Payment obj = new Payment();//change 'Form3' depending on the name u have 
            obj.Show();
        }
    }
}
